This just my homework for school.
Nothing serious, only practice :D

-Magical_Girls