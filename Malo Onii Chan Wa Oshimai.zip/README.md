# Ce site a entièrement été fait par Malo.

# NE PAS UTILISER FIREFOX !!!
## Firefox ne permet pas d'utiliser ```localStorage``` correctement. Par conséquent, le changeur de thème ne fonctionne pas !
## Firefox ne permet pas non plus de modifier la scrollbar ! (avec ```::-webkit-scrollbar``` par exemple)
## Firefox ne permet pas non plus d'utiliser correctement les ```place-content: center``` et ```place-items:center```

### Il y a un bug avec ```width: 100%;``` qui ne met pas la navbar entièrement, malgré le 100%.

J'ai du traduire les descriptions des personnages car elles venaient du Wikipedia anglais.
Par conséquent cela peut ne pas correspondre à 100% à celles d'origine.

Je n'ai par ailleurs pas traduis les critiques pour laisser les originales.

J'ai préféré mettre les script directement dans les fichiers HTML car je trouve ça plus simple de travailler avec.
(Même si en cours je disais que ce n'était pas une bonne chose ahah)
-Malo